# CUTI REQUEST WEB APPLICATION

> Kerja, Kerja, Kerja, Tipes.. Liburan Kali ah. Chillin' brings a good vibes. So, Refresh your mind!~~

**_Requirements :_** <br />

1. PHP 7.4 ++ <br />
2. MariaDB 10.4.2 ++ <br />

**_OR_** you can just download the latest XAMPP from : [Click Me!](https://sourceforge.net/projects/xampp/files/XAMPP%20Windows/).
<br />

**Put me in htdocs folder**<br />
to access the web app write : [localhost:80](http://localhost/cuti_request) **_OR_** [localhost:modifiedPort](http://localhost:8080/cuti_request).

There are 3 test accounts, those are : <br />

- Admin Account : <br />
  User : admin <br />
  Pass : admin <br />
- Manager Account : <br />
  User : human <br />
  Pass : human <br />
- Staff Account : <br />
  User : staff <br />
  Pass : staff <br />

<br />

![Login Image](preview/login.png)
![Dashboard](preview/dashboard.png)
![Manage Cuti](preview/manage.png)
![Pengajuan Cuti](preview/pengajuan.png)
![Laporan Cuti](preview/laporan.png)


**Thanks to me later.**
